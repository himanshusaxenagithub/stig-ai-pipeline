"""Scan reports: JSON for module 3, Markdown for the human holding the ATO.

The Markdown report leads with what did *not* run. An engineer reading a
compliance report needs to know the shape of the evidence gap before they
read the score, or the score misleads them.
"""

from __future__ import annotations

import json

from .evaluate import PASS, FAIL, ERROR, MANUAL, SKIPPED
from .scan import ScanReport, SEVERITY_LABEL
from .pdf import to_pdf
from .summary import breakdown_rows, coverage_rows, severity_rows, summarize_report

_ORDER = {"high": 0, "medium": 1, "low": 2}
_ICON = {PASS: "PASS", FAIL: "FAIL", ERROR: "ERROR", MANUAL: "MANUAL", SKIPPED: "SKIP"}


def to_json(report: ScanReport) -> str:
    return json.dumps(report.to_dict(), indent=2) + "\n"


def to_markdown(report: ScanReport) -> str:
    c = report.counts()
    evaluated = c[PASS] + c[FAIL]
    total = len(report.results)
    untrusted = [r for r in report.results if not r.trusted and r.status in (PASS, FAIL)]

    L: list[str] = []
    L.append(f"# STIG scan report — {report.stig_title or report.pack_id}")
    L.append("")
    L.append(f"- **Check pack:** `{report.pack_id}` ({report.stig_version})")
    L.append(f"- **Host:** {report.host.get('hostname', '?')} "
             f"({report.host.get('system', '?')} {report.host.get('macos_version') or report.host.get('release', '')})")
    L.append(f"- **Run:** {report.started} → {report.finished}  ·  "
             f"source: {report.options.get('runner')}")
    L.append("")

    L.append("## Coverage")
    L.append("")
    L.append("| Outcome | Count | Meaning |")
    L.append("|---|---:|---|")
    L.append(f"| Pass | {c[PASS]} | check ran and the system met the requirement |")
    L.append(f"| Fail | {c[FAIL]} | check ran and the system did not meet it |")
    L.append(f"| Error | {c[ERROR]} | check could not produce a usable result |")
    L.append(f"| Manual | {c[MANUAL]} | STIG requires human inspection |")
    L.append(f"| Skipped | {c[SKIPPED]} | not executed — see reasons below |")
    L.append(f"| **Total** | **{total}** | |")
    L.append("")
    pct = (evaluated / total * 100) if total else 0
    L.append(f"**{evaluated} of {total} rules ({pct:.1f}%) were actually evaluated on this host.** "
             f"The remaining {total - evaluated} produced no compliance evidence and must not be "
             f"counted as either compliant or non-compliant.")
    L.append("")

    story = summarize_report(report)
    L.append("## What this means")
    L.append("")
    L.append(f"**{story.headline}**")
    L.append("")
    L.append(story.meaning)
    L.append("")
    L.append(story.next_step)
    L.append("")
    L.append(f"*{story.judged_line}*")
    L.append("")
    L.append("```")
    for label, bar, caption in breakdown_rows(story):
        L.append(f"{label:<22} {bar}  {caption}")
    if any(story.fails_by_severity.values()):
        L.append("")
        L.append("Fails by severity")
        for label, bar, caption in severity_rows(story):
            L.append(f"{label:<22} {bar}  {caption}")
    L.append("")
    L.append("Coverage")
    for label, bar, caption in coverage_rows(story):
        L.append(f"{label:<22} {bar}  {caption}")
    L.append("```")
    L.append("")

    if untrusted:
        L.append("> **WARNING — untrusted results.** "
                 f"{len(untrusted)} result(s) came from checks that no human has approved "
                 "(`--include-unreviewed`). They are shown for development purposes and are "
                 "not admissible as compliance evidence. Approve the checks with "
                 "`stigscan approve` and re-run.")
        L.append("")

    cat1 = report.cat1_failures()
    if cat1:
        L.append(f"## CAT I failures ({len(cat1)})")
        L.append("")
        for r in cat1:
            L.append(f"- **{r.stig_id}** ({r.group_id}) — {r.title}")
            L.append(f"  - {r.detail}")
        L.append("")

    L.append("## Results")
    L.append("")
    L.append("| Status | Severity | STIG ID | Rule | Detail |")
    L.append("|---|---|---|---|---|")
    for r in sorted(report.results,
                    key=lambda r: ({PASS: 3, FAIL: 0, ERROR: 1, MANUAL: 2, SKIPPED: 4}[r.status],
                                   _ORDER.get(r.severity, 9), r.stig_id)):
        title = (r.title[:70] + "…") if len(r.title) > 70 else r.title
        detail = (r.detail[:90] + "…") if len(r.detail) > 90 else r.detail
        flag = "" if r.trusted else " ⚠︎"
        L.append(f"| {_ICON[r.status]}{flag} | {SEVERITY_LABEL.get(r.severity, r.severity)} "
                 f"| `{r.stig_id}` | {title.replace('|', '/')} | {detail.replace('|', '/')} |")
    L.append("")

    skipped = [r for r in report.results if r.status == SKIPPED]
    if skipped:
        reasons: dict[str, int] = {}
        for r in skipped:
            key = r.detail.split(";")[0].split("(")[0].strip()
            reasons[key] = reasons.get(key, 0) + 1
        L.append("## Why checks were skipped")
        L.append("")
        for reason, n in sorted(reasons.items(), key=lambda x: -x[1]):
            L.append(f"- {n} × {reason}")
        L.append("")

    L.append("---")
    L.append("")
    L.append("Generated by `stig-scan`, module 2 of stig-ai-pipeline. Check commands are "
             "human-approved and content-frozen; the scanner executes no unapproved code and "
             "makes no configuration changes. Authoritative requirements are the DISA STIG "
             "text, not this report.")
    return "\n".join(L) + "\n"
